package groupproject;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class GroupProject extends Application {
    Stage window;
    Scene scene1, scene2;
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;
        
        Label startLabel = new Label("Welcome to Garbo!\nClick Play to play or \nExit to exit.");
        Button play = new Button("Play");
        play.setOnAction(e -> window.setScene(scene2));
        
        //layout 1
        VBox layout1 = new VBox(20);
        layout1.getChildren().addAll(startLabel, play);
        scene1 = new Scene(layout1, 200, 300);
        
        //button 2
        Button goBack = new Button("Go back");
        goBack.setOnAction(e -> window.setScene(scene1));
        
        //layout 2
        StackPane layout2 = new StackPane();
        layout2.getChildren().add(goBack);
        scene2 = new Scene(layout2, 200, 300);
        
        window.setScene(scene1);
        window.setTitle("Title");
        window.show();
    }
}
